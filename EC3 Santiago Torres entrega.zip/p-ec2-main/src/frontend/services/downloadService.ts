import { apiClient, normalizarError } from './apiClient';
import type {
  CrearDescargaPayload,
  DescargaCreadaResponse,
  EstadoDescargaResponse,
  ListaDescargasResponse,
  ReintentarDescargaResponse,
} from '../types';

/**
 * Servicio de acceso a la API de descargas.
 *
 * Cubre exactamente los 4 endpoints expuestos por el backend
 * (src/interfaces/routes/descargas.routes.ts):
 *   POST   /api/descargas
 *   GET    /api/descargas
 *   GET    /api/descargas/:id/estado
 *   POST   /api/descargas/:id/reintentar
 *
 * El backend NO expone un endpoint de detalle individual (GET /:id)
 * ni de cancelación (POST /:id/cancelar). La UI resuelve "ver detalles"
 * reutilizando los datos ya disponibles en la lista/estado, y el botón
 * de "Cancelar" se mantiene deshabilitado (ver DownloadList.vue).
 */
export const downloadService = {
  /**
   * Crea una nueva descarga.
   * POST /api/descargas
   */
  async crearDescarga(payload: CrearDescargaPayload): Promise<DescargaCreadaResponse> {
    try {
      const { data } = await apiClient.post<DescargaCreadaResponse>(
        '/api/descargas',
        payload,
      );
      return data;
    } catch (error) {
      throw normalizarError(error);
    }
  },

  /**
   * Lista todas las descargas registradas, junto con el resumen de
   * totales por estado.
   * GET /api/descargas
   */
  async listarDescargas(): Promise<ListaDescargasResponse> {
    try {
      const { data } = await apiClient.get<ListaDescargasResponse>('/api/descargas');
      return data;
    } catch (error) {
      throw normalizarError(error);
    }
  },

  /**
   * Obtiene el estado actual de una descarga puntual.
   * GET /api/descargas/:id/estado
   */
  async obtenerEstado(id: string): Promise<EstadoDescargaResponse> {
    try {
      const { data } = await apiClient.get<EstadoDescargaResponse>(
        `/api/descargas/${id}/estado`,
      );
      return data;
    } catch (error) {
      throw normalizarError(error);
    }
  },

  /**
   * Reencola una descarga que se encuentra en estado FALLIDA.
   * POST /api/descargas/:id/reintentar
   */
  async reintentarDescarga(id: string): Promise<ReintentarDescargaResponse> {
    try {
      const { data } = await apiClient.post<ReintentarDescargaResponse>(
        `/api/descargas/${id}/reintentar`,
      );
      return data;
    } catch (error) {
      throw normalizarError(error);
    }
  },
};
