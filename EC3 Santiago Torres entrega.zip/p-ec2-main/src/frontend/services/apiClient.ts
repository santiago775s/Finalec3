import axios, { AxiosError, type AxiosInstance } from 'axios';
import { DownloadApiError, type ApiErrorBody } from '../types';

/**
 * URL base de la API. Por defecto queda vacía para que las
 * peticiones usen rutas relativas (/api/descargas) y sean
 * resueltas por el proxy de Vite hacia http://localhost:3000
 * en desarrollo (ver vite.config.ts -> server.proxy).
 * Se puede sobreescribir con la variable de entorno
 * VITE_API_BASE_URL (ej. al desplegar el frontend en otro host
 * sin proxy disponible).
 */
const BASE_URL = (import.meta as any).env?.VITE_API_BASE_URL ?? '';

export const apiClient: AxiosInstance = axios.create({
  baseURL: BASE_URL,
  timeout: 10_000,
  headers: {
    'Content-Type': 'application/json',
  },
});

/**
 * Normaliza cualquier error de axios a un DownloadApiError con un
 * mensaje entendible para el usuario final, sin perder el código
 * de estado HTTP ni el código de dominio que devuelve el backend
 * (errorMiddleware.ts usa "error", validationMiddleware usa "error",
 * y los controllers de excepciones de negocio usan "message").
 */
export function normalizarError(error: unknown): DownloadApiError {
  if (axios.isAxiosError(error)) {
    const axiosError = error as AxiosError<ApiErrorBody>;

    if (axiosError.response) {
      const { status, data } = axiosError.response;
      const mensaje =
        data?.message || data?.error || 'Ocurrió un error al comunicarse con el servidor.';
      return new DownloadApiError(mensaje, status, data?.codigo);
    }

    if (axiosError.code === 'ECONNABORTED') {
      return new DownloadApiError(
        'La solicitud tardó demasiado en responder. Intenta nuevamente.',
      );
    }

    return new DownloadApiError(
      'No se pudo conectar con el servidor. Verifica que el backend esté en ejecución.',
    );
  }

  if (error instanceof Error) {
    return new DownloadApiError(error.message);
  }

  return new DownloadApiError('Ocurrió un error inesperado.');
}
