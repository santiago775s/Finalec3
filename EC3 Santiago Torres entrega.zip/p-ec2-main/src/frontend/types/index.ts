/**
 * Tipos del dominio de descargas en el frontend.
 *
 * Estos tipos reflejan EXACTAMENTE las formas de respuesta que devuelve
 * el backend (src/interfaces/controllers/descargas.controller.ts), no
 * los DTOs ideales declarados en src/shared/types/index.ts del backend,
 * que en la práctica no coinciden 1:1 con lo que el controller responde.
 */

/** Tipos de descargador soportados por el backend. */
export type TipoDescarga = 'http' | 'ftp' | 'mock';

/**
 * Estados posibles de una descarga según el backend
 * (src/shared/enums/index.ts -> EstadoDescarga).
 */
export type EstadoDescarga =
  | 'PENDIENTE'
  | 'EN_PROGRESO'
  | 'COMPLETADA'
  | 'FALLIDA'
  | 'REINTENTANDO'
  | 'CANCELADA';

/** Forma de cada elemento dentro de la respuesta de GET /api/descargas */
export interface DescargaResumen {
  id: string;
  url: string;
  tipo: string;
  estado: EstadoDescarga;
  progreso: number;
  intentos: number;
}

/** Respuesta completa de GET /api/descargas */
export interface ListaDescargasResponse {
  descargas: DescargaResumen[];
  total: number;
  completadas: number;
  pendientes: number;
  fallidas: number;
}

/** Respuesta de POST /api/descargas */
export interface DescargaCreadaResponse {
  id: string;
  url: string;
  tipo: string;
  estado: EstadoDescarga;
  mensaje: string;
}

/** Respuesta de GET /api/descargas/:id/estado */
export interface EstadoDescargaResponse {
  id: string;
  url: string;
  tipo: string;
  estado: EstadoDescarga;
  progreso: number;
  intentos: number;
}

/** Respuesta de POST /api/descargas/:id/reintentar */
export interface ReintentarDescargaResponse {
  id: string;
  estado: EstadoDescarga;
  mensaje: string;
}

/** Payload para crear una descarga (POST /api/descargas) */
export interface CrearDescargaPayload {
  url: string;
  tipo: TipoDescarga;
  maxReintentos: number;
}

/**
 * Modelo de descarga usado internamente en el store del frontend.
 * Incluye campos derivados (fechaRegistro local) ya que el backend
 * no devuelve fecha de creación en sus respuestas actuales.
 */
export interface Descarga {
  id: string;
  url: string;
  tipo: TipoDescarga | string;
  estado: EstadoDescarga;
  progreso: number;
  intentos: number;
  /** Fecha en que el frontend detectó/creó este registro (timestamp ISO local) */
  fechaRegistro: string;
}

/** Forma estándar de error que devuelve errorMiddleware del backend */
export interface ApiErrorBody {
  error?: string;
  message?: string;
  codigo?: string;
  statusCode?: number;
}

/** Error normalizado que usa el frontend para mostrar mensajes al usuario */
export class DownloadApiError extends Error {
  public readonly statusCode?: number;
  public readonly codigo?: string;

  constructor(message: string, statusCode?: number, codigo?: string) {
    super(message);
    this.name = 'DownloadApiError';
    this.statusCode = statusCode;
    this.codigo = codigo;
  }
}

/** Opciones del formulario de nueva descarga */
export interface NuevaDescargaFormState {
  url: string;
  tipo: TipoDescarga;
  maxReintentos: number;
}

/** Resultado de validar un campo del formulario */
export interface ValidationResult {
  valido: boolean;
  mensaje?: string;
}
