import { createApp } from 'vue';
import { createPinia } from 'pinia';
import PrimeVue from 'primevue/config';
import ToastService from 'primevue/toastservice';
import Tooltip from 'primevue/tooltip';

import 'primevue/resources/themes/lara-light-blue/theme.css';
import 'primevue/resources/primevue.min.css';
import 'primeicons/primeicons.css';

import App from './App.vue';

const app = createApp(App);

app.use(createPinia());
app.use(PrimeVue, { ripple: true });
app.use(ToastService);
app.directive('tooltip', Tooltip);

app.mount('#app');
