<script setup lang="ts">
import DashboardPage from './pages/DashboardPage.vue';
</script>

<template>
  <DashboardPage />
</template>

<style>
:root {
  --color-bg: #f5f6fa;
}

* {
  box-sizing: border-box;
}

body {
  margin: 0;
  background-color: var(--color-bg);
  font-family: 'Inter', system-ui, -apple-system, Segoe UI, Roboto, sans-serif;
  color: #111827;
}
</style>
