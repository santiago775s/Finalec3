import type { EstadoDescarga } from '../types';

/**
 * Utilidades de formateo para presentar datos de descargas en la UI.
 */

/** Etiquetas legibles en español para cada estado del backend. */
const ETIQUETAS_ESTADO: Record<EstadoDescarga, string> = {
  PENDIENTE: 'Pendiente',
  EN_PROGRESO: 'En progreso',
  COMPLETADA: 'Completada',
  FALLIDA: 'Fallida',
  REINTENTANDO: 'Reintentando',
  CANCELADA: 'Cancelada',
};

/** Severidad PrimeVue (Tag/Badge) asociada a cada estado. */
const SEVERIDAD_ESTADO: Record<EstadoDescarga, string> = {
  PENDIENTE: 'secondary',
  EN_PROGRESO: 'info',
  COMPLETADA: 'success',
  FALLIDA: 'danger',
  REINTENTANDO: 'warning',
  CANCELADA: 'contrast',
};

export function etiquetaEstado(estado: EstadoDescarga | string): string {
  return ETIQUETAS_ESTADO[estado as EstadoDescarga] ?? estado;
}

export function severidadEstado(estado: EstadoDescarga | string): string {
  return SEVERIDAD_ESTADO[estado as EstadoDescarga] ?? 'secondary';
}

/** Etiqueta legible para el tipo de descargador. */
export function etiquetaTipo(tipo: string): string {
  const mapa: Record<string, string> = {
    http: 'HTTP',
    ftp: 'FTP',
    mock: 'Mock',
  };
  return mapa[tipo] ?? tipo.toUpperCase();
}

/** Formatea una fecha ISO a formato local corto (es-BO). */
export function formatearFecha(fechaIso: string): string {
  try {
    const fecha = new Date(fechaIso);
    return fecha.toLocaleString('es-BO', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  } catch {
    return fechaIso;
  }
}

/** Trunca una URL larga para mostrarla en espacios reducidos (ej. tabla). */
export function truncarUrl(url: string, maxLargo = 48): string {
  if (url.length <= maxLargo) return url;
  return `${url.slice(0, maxLargo - 1)}…`;
}

/** Devuelve el progreso clamped entre 0 y 100. */
export function clampProgreso(progreso: number): number {
  if (Number.isNaN(progreso)) return 0;
  return Math.min(100, Math.max(0, Math.round(progreso)));
}
