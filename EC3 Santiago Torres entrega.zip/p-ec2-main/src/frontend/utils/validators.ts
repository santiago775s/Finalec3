import type { ValidationResult } from '../types';

/**
 * Utilidades de validación para el formulario de descargas.
 * Replican en el cliente las mismas reglas que aplica el backend
 * (validationMiddleware.ts y UrlDescarga value object) para dar
 * feedback inmediato antes de golpear la API.
 */

const MAX_REINTENTOS_PERMITIDOS = 5;

/**
 * Valida que una cadena sea una URL bien formada usando el
 * constructor nativo URL, igual que hace el backend.
 */
export function validarUrl(url: string): ValidationResult {
  const valor = url.trim();

  if (!valor) {
    return { valido: false, mensaje: 'La URL es obligatoria.' };
  }

  try {
    // eslint-disable-next-line no-new
    new URL(valor);
    return { valido: true };
  } catch {
    return {
      valido: false,
      mensaje: 'Ingresa una URL válida (ej: https://ejemplo.com/archivo.pdf).',
    };
  }
}

/**
 * Valida el tipo de descargador seleccionado.
 */
export function validarTipo(tipo: string): ValidationResult {
  if (!tipo || !['http', 'ftp', 'mock'].includes(tipo)) {
    return {
      valido: false,
      mensaje: 'Selecciona un tipo de descarga: HTTP, FTP o Mock.',
    };
  }
  return { valido: true };
}

/**
 * Valida el número máximo de reintentos (entre 1 y 5, según el enunciado).
 */
export function validarMaxReintentos(maxReintentos: number): ValidationResult {
  if (
    !Number.isInteger(maxReintentos) ||
    maxReintentos < 1 ||
    maxReintentos > MAX_REINTENTOS_PERMITIDOS
  ) {
    return {
      valido: false,
      mensaje: `Los reintentos deben ser un número entero entre 1 y ${MAX_REINTENTOS_PERMITIDOS}.`,
    };
  }
  return { valido: true };
}

export { MAX_REINTENTOS_PERMITIDOS };
