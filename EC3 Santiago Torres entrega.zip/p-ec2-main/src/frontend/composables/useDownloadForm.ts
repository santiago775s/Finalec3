import { reactive, ref, computed } from 'vue';
import { useDownloadStore } from '../stores/downloadStore';
import {
  validarUrl,
  validarTipo,
  validarMaxReintentos,
  MAX_REINTENTOS_PERMITIDOS,
} from '../utils/validators';
import type { NuevaDescargaFormState, TipoDescarga } from '../types';

/**
 * Composable para el formulario de creación de descargas
 * (DownloadForm.vue). Centraliza estado reactivo, validación en
 * tiempo real por campo y el envío contra el store.
 */
export function useDownloadForm() {
  const store = useDownloadStore();

  const form = reactive<NuevaDescargaFormState>({
    url: '',
    tipo: 'mock',
    maxReintentos: 3,
  });

  const erroresCampo = reactive<{ url?: string; tipo?: string; maxReintentos?: string }>({});
  const tocado = reactive<{ url: boolean; tipo: boolean; maxReintentos: boolean }>({
    url: false,
    tipo: false,
    maxReintentos: false,
  });

  const enviando = computed(() => store.creandoDescarga);
  const mensajeExito = ref<string | null>(null);

  function validarCampo(campo: 'url' | 'tipo' | 'maxReintentos'): void {
    if (campo === 'url') {
      const resultado = validarUrl(form.url);
      erroresCampo.url = resultado.valido ? undefined : resultado.mensaje;
    }
    if (campo === 'tipo') {
      const resultado = validarTipo(form.tipo);
      erroresCampo.tipo = resultado.valido ? undefined : resultado.mensaje;
    }
    if (campo === 'maxReintentos') {
      const resultado = validarMaxReintentos(form.maxReintentos);
      erroresCampo.maxReintentos = resultado.valido ? undefined : resultado.mensaje;
    }
  }

  function marcarTocado(campo: 'url' | 'tipo' | 'maxReintentos'): void {
    tocado[campo] = true;
    validarCampo(campo);
  }

  const formularioValido = computed(() => {
    return (
      validarUrl(form.url).valido &&
      validarTipo(form.tipo).valido &&
      validarMaxReintentos(form.maxReintentos).valido
    );
  });

  function resetearFormulario(): void {
    form.url = '';
    form.tipo = 'mock';
    form.maxReintentos = 3;
    erroresCampo.url = undefined;
    erroresCampo.tipo = undefined;
    erroresCampo.maxReintentos = undefined;
    tocado.url = false;
    tocado.tipo = false;
    tocado.maxReintentos = false;
  }

  async function enviarFormulario(): Promise<boolean> {
    tocado.url = true;
    tocado.tipo = true;
    tocado.maxReintentos = true;
    validarCampo('url');
    validarCampo('tipo');
    validarCampo('maxReintentos');

    if (!formularioValido.value) {
      return false;
    }

    mensajeExito.value = null;

    const creada = await store.crearDescarga({
      url: form.url.trim(),
      tipo: form.tipo as TipoDescarga,
      maxReintentos: form.maxReintentos,
    });

    if (creada) {
      mensajeExito.value = `Descarga ${creada.id.slice(0, 8)}… encolada correctamente.`;
      resetearFormulario();
      return true;
    }

    return false;
  }

  return {
    form,
    erroresCampo,
    tocado,
    enviando,
    mensajeExito,
    formularioValido,
    marcarTocado,
    enviarFormulario,
    resetearFormulario,
    maxReintentosPermitidos: MAX_REINTENTOS_PERMITIDOS,
  };
}
