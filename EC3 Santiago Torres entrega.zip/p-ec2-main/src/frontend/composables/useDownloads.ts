import { computed, onMounted, onUnmounted } from 'vue';
import { useDownloadStore } from '../stores/downloadStore';

/**
 * Composable de alto nivel para consumir el listado de descargas
 * con actualización en tiempo real (polling cada 2s, ver enunciado
 * sección 1.3 "Actualización en tiempo real").
 *
 * Encapsula el ciclo de vida del polling: lo arranca al montar el
 * componente que lo usa y lo detiene al desmontarlo, para no dejar
 * timers corriendo en segundo plano.
 */
export function useDownloads() {
  const store = useDownloadStore();

  const descargas = computed(() => store.descargas);
  const totales = computed(() => store.totales);
  const cargando = computed(() => store.cargandoLista);
  const error = computed(() => store.error);

  onMounted(() => {
    store.iniciarPolling();
  });

  onUnmounted(() => {
    store.detenerPolling();
  });

  async function reintentar(id: string): Promise<boolean> {
    return store.reintentarDescarga(id);
  }

  async function refrescarAhora(): Promise<void> {
    await store.cargarDescargas();
  }

  function limpiarError(): void {
    store.limpiarError();
  }

  return {
    descargas,
    totales,
    cargando,
    error,
    reintentar,
    refrescarAhora,
    limpiarError,
  };
}
