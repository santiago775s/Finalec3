<script setup lang="ts">
import { watch } from 'vue';
import Toast from 'primevue/toast';
import { useToast } from 'primevue/usetoast';
import DownloadForm from '../components/DownloadForm.vue';
import DownloadList from '../components/DownloadList.vue';
import ErrorBoundary from '../components/ErrorBoundary.vue';
import StatusDistributionChart from '../components/StatusDistributionChart.vue';
import HourlyCompletionChart from '../components/HourlyCompletionChart.vue';
import { useDownloads } from '../composables/useDownloads';

/**
 * Página principal (Dashboard). Combina:
 *  - Formulario de nueva descarga
 *  - Tabla de descargas con actualización en tiempo real (polling)
 *  - Resumen de totales
 *  - Gráficos de distribución de estados y completadas por hora
 */
const toast = useToast();
const { descargas, totales, cargando, error, reintentar, limpiarError } = useDownloads();

watch(error, (nuevoError) => {
  if (nuevoError) {
    toast.add({
      severity: 'error',
      summary: 'Error',
      detail: nuevoError,
      life: 4000,
    });
    limpiarError();
  }
});

async function manejarReintento(id: string): Promise<void> {
  const exito = await reintentar(id);
  toast.add({
    severity: exito ? 'success' : 'error',
    summary: exito ? 'Reintento encolado' : 'No se pudo reintentar',
    detail: exito
      ? `La descarga ${id.slice(0, 8)}… volvió a la cola.`
      : 'Revisa que la descarga esté en estado Fallida.',
    life: 3500,
  });
}

function manejarNuevaDescarga(): void {
  toast.add({
    severity: 'success',
    summary: 'Descarga iniciada',
    detail: 'Tu descarga fue encolada y aparecerá en la tabla en instantes.',
    life: 3000,
  });
}
</script>

<template>
  <main class="dashboard">
    <Toast />

    <header class="dashboard__header">
      <div>
        <h1 class="dashboard__title">Simulador de Descargas Concurrentes</h1>
        <p class="dashboard__subtitle">
          Monitoreo en tiempo real del sistema basado en Worker Threads y DDD.
        </p>
      </div>
      <div class="dashboard__summary">
        <div class="dashboard__summary-item">
          <span class="dashboard__summary-value">{{ totales.total }}</span>
          <span class="dashboard__summary-label">Total</span>
        </div>
        <div class="dashboard__summary-item dashboard__summary-item--pending">
          <span class="dashboard__summary-value">{{ totales.pendientes }}</span>
          <span class="dashboard__summary-label">En curso</span>
        </div>
        <div class="dashboard__summary-item dashboard__summary-item--success">
          <span class="dashboard__summary-value">{{ totales.completadas }}</span>
          <span class="dashboard__summary-label">Completadas</span>
        </div>
        <div class="dashboard__summary-item dashboard__summary-item--error">
          <span class="dashboard__summary-value">{{ totales.fallidas }}</span>
          <span class="dashboard__summary-label">Fallidas</span>
        </div>
      </div>
    </header>

    <section class="dashboard__grid">
      <ErrorBoundary class="dashboard__form-area">
        <DownloadForm :on-submit="manejarNuevaDescarga" />
      </ErrorBoundary>

      <div class="dashboard__charts">
        <ErrorBoundary>
          <StatusDistributionChart :downloads="descargas" />
        </ErrorBoundary>
        <ErrorBoundary>
          <HourlyCompletionChart :downloads="descargas" />
        </ErrorBoundary>
      </div>
    </section>

    <ErrorBoundary>
      <DownloadList :downloads="descargas" @reintentar="manejarReintento" />
    </ErrorBoundary>

    <p v-if="cargando && descargas.length === 0" class="dashboard__loading">
      Cargando descargas…
    </p>
  </main>
</template>

<style scoped>
.dashboard {
  display: flex;
  flex-direction: column;
  gap: 1.5rem;
  max-width: 1200px;
  margin: 0 auto;
  padding: 1.5rem;
}

.dashboard__header {
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
  align-items: flex-start;
  gap: 1rem;
}

.dashboard__title {
  margin: 0;
  font-size: 1.5rem;
  font-weight: 800;
  color: #111827;
}

.dashboard__subtitle {
  margin: 0.25rem 0 0;
  color: #6b7280;
  font-size: 0.9rem;
}

.dashboard__summary {
  display: flex;
  gap: 0.75rem;
}

.dashboard__summary-item {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  min-width: 5rem;
  padding: 0.6rem 0.75rem;
  border-radius: 0.75rem;
  background-color: #f3f4f6;
}

.dashboard__summary-item--pending {
  background-color: #dbeafe;
}
.dashboard__summary-item--success {
  background-color: #dcfce7;
}
.dashboard__summary-item--error {
  background-color: #fee2e2;
}

.dashboard__summary-value {
  font-size: 1.25rem;
  font-weight: 800;
  color: #111827;
}

.dashboard__summary-label {
  font-size: 0.7rem;
  color: #4b5563;
  text-transform: uppercase;
  letter-spacing: 0.04em;
}

.dashboard__grid {
  display: grid;
  grid-template-columns: 1.1fr 1fr;
  gap: 1.5rem;
  align-items: start;
}

.dashboard__charts {
  display: flex;
  flex-direction: column;
  gap: 1.5rem;
}

.dashboard__loading {
  text-align: center;
  color: #6b7280;
}

@media (max-width: 900px) {
  .dashboard__grid {
    grid-template-columns: 1fr;
  }
  .dashboard__summary {
    flex-wrap: wrap;
  }
}
</style>
