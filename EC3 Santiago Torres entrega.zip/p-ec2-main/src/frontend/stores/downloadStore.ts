import { defineStore } from 'pinia';
import { downloadService } from '../services/downloadService';
import type { CrearDescargaPayload, Descarga, DescargaResumen } from '../types';
import { DownloadApiError } from '../types';

interface DownloadStoreState {
  /** Mapa id -> descarga, para actualizaciones O(1) durante el polling */
  descargasPorId: Map<string, Descarga>;
  /** Orden de inserción para mostrar las descargas más recientes primero */
  ordenIds: string[];
  cargandoLista: boolean;
  creandoDescarga: boolean;
  error: string | null;
  pollingActivo: boolean;
  intervaloPollingMs: number;
}

let pollingHandle: ReturnType<typeof setInterval> | null = null;

function resumenADescarga(resumen: DescargaResumen, fechaPrevia?: string): Descarga {
  return {
    id: resumen.id,
    url: resumen.url,
    tipo: resumen.tipo,
    estado: resumen.estado,
    progreso: resumen.progreso,
    intentos: resumen.intentos,
    fechaRegistro: fechaPrevia ?? new Date().toISOString(),
  };
}

export const useDownloadStore = defineStore('downloads', {
  state: (): DownloadStoreState => ({
    descargasPorId: new Map(),
    ordenIds: [],
    cargandoLista: false,
    creandoDescarga: false,
    error: null,
    pollingActivo: false,
    intervaloPollingMs: 2000,
  }),

  getters: {
    descargas(state): Descarga[] {
      return state.ordenIds
        .map((id) => state.descargasPorId.get(id))
        .filter((d): d is Descarga => Boolean(d));
    },
    totales(state) {
      const lista = state.ordenIds
        .map((id) => state.descargasPorId.get(id))
        .filter((d): d is Descarga => Boolean(d));

      return {
        total: lista.length,
        completadas: lista.filter((d) => d.estado === 'COMPLETADA').length,
        pendientes: lista.filter(
          (d) => d.estado === 'PENDIENTE' || d.estado === 'EN_PROGRESO' || d.estado === 'REINTENTANDO',
        ).length,
        fallidas: lista.filter((d) => d.estado === 'FALLIDA').length,
      };
    },
  },

  actions: {
    /**
     * Sincroniza el store con la respuesta de GET /api/descargas,
     * preservando la fecha de registro local ya conocida para no
     * "reordenar" visualmente las filas existentes en cada poll.
     */
    _sincronizarDesdeLista(resumenes: DescargaResumen[]) {
      const idsNuevos: string[] = [];

      for (const resumen of resumenes) {
        const existente = this.descargasPorId.get(resumen.id);
        this.descargasPorId.set(
          resumen.id,
          resumenADescarga(resumen, existente?.fechaRegistro),
        );
        if (!existente) {
          idsNuevos.push(resumen.id);
        }
      }

      // Mantener los nuevos al inicio (más recientes primero)
      this.ordenIds = [...idsNuevos, ...this.ordenIds];
    },

    async cargarDescargas() {
      this.cargandoLista = true;
      this.error = null;
      try {
        const respuesta = await downloadService.listarDescargas();
        this._sincronizarDesdeLista(respuesta.descargas);
      } catch (error) {
        this.error =
          error instanceof DownloadApiError
            ? error.message
            : 'No se pudieron cargar las descargas.';
      } finally {
        this.cargandoLista = false;
      }
    },

    async crearDescarga(payload: CrearDescargaPayload): Promise<Descarga | null> {
      this.creandoDescarga = true;
      this.error = null;
      try {
        const creada = await downloadService.crearDescarga(payload);
        const descarga: Descarga = {
          id: creada.id,
          url: creada.url,
          tipo: creada.tipo,
          estado: creada.estado,
          progreso: 0,
          intentos: 0,
          fechaRegistro: new Date().toISOString(),
        };
        this.descargasPorId.set(descarga.id, descarga);
        this.ordenIds = [descarga.id, ...this.ordenIds];
        return descarga;
      } catch (error) {
        this.error =
          error instanceof DownloadApiError
            ? error.message
            : 'No se pudo crear la descarga.';
        return null;
      } finally {
        this.creandoDescarga = false;
      }
    },

    async reintentarDescarga(id: string): Promise<boolean> {
      this.error = null;
      try {
        const respuesta = await downloadService.reintentarDescarga(id);
        const existente = this.descargasPorId.get(id);
        if (existente) {
          this.descargasPorId.set(id, {
            ...existente,
            estado: respuesta.estado,
            progreso: 0,
          });
        }
        return true;
      } catch (error) {
        this.error =
          error instanceof DownloadApiError
            ? error.message
            : 'No se pudo reintentar la descarga.';
        return false;
      }
    },

    /** Inicia el polling periódico contra GET /api/descargas. */
    iniciarPolling() {
      if (this.pollingActivo) return;
      this.pollingActivo = true;
      this.cargarDescargas();
      pollingHandle = setInterval(() => {
        this.cargarDescargas();
      }, this.intervaloPollingMs);
    },

    detenerPolling() {
      if (pollingHandle) {
        clearInterval(pollingHandle);
        pollingHandle = null;
      }
      this.pollingActivo = false;
    },

    limpiarError() {
      this.error = null;
    },
  },
});
