import { DescargadorFactory } from '../../../domain/factories/descargadorFactory';
import { DescargadorHttp } from '../../../infrastructure/descargadores/descargadorHttp';
import { DescargadorFtp } from '../../../infrastructure/descargadores/descargadorFtp';
import { DescargadorMock } from '../../../infrastructure/descargadores/descargadorMock';
import { ErrorTipoInvalido } from '../../../domain/errors/index';

/**
 * Tests unitarios de DescargadorFactory
 * (src/domain/factories/descargadorFactory.ts).
 */
describe('DescargadorFactory', () => {
  it('debe crear un DescargadorHttp para tipo "http"', () => {
    expect(DescargadorFactory.crear('http')).toBeInstanceOf(DescargadorHttp);
  });

  it('debe crear un DescargadorFtp para tipo "ftp"', () => {
    expect(DescargadorFactory.crear('ftp')).toBeInstanceOf(DescargadorFtp);
  });

  it('debe crear un DescargadorMock para tipo "mock"', () => {
    expect(DescargadorFactory.crear('mock')).toBeInstanceOf(DescargadorMock);
  });

  it('debe ser insensible a mayúsculas/minúsculas en el tipo', () => {
    expect(DescargadorFactory.crear('HTTP')).toBeInstanceOf(DescargadorHttp);
    expect(DescargadorFactory.crear('Mock')).toBeInstanceOf(DescargadorMock);
  });

  it('debe lanzar ErrorTipoInvalido para un tipo no soportado', () => {
    expect(() => DescargadorFactory.crear('torrent')).toThrow(ErrorTipoInvalido);
  });
});
