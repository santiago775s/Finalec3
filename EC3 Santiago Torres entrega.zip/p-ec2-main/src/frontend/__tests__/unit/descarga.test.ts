import { Descarga } from '../../../domain/entities/descarga';
import { EstadoDescarga } from '../../../shared/enums';

/**
 * Tests unitarios de la entidad de dominio Descarga
 * (src/domain/entities/descarga.ts).
 */
describe('Descarga (entidad de dominio)', () => {
  function crearDescarga(): Descarga {
    return new Descarga('id-1', 'https://example.com/archivo.pdf', 'mock');
  }

  it('debe inicializarse en estado PENDIENTE con progreso 0', () => {
    const descarga = crearDescarga();
    expect(descarga.estado).toBe(EstadoDescarga.PENDIENTE);
    expect(descarga.progreso).toBe(0);
    expect(descarga.intentos).toBe(0);
  });

  it('iniciar() debe cambiar el estado a EN_PROGRESO', () => {
    const descarga = crearDescarga();
    descarga.iniciar();
    expect(descarga.estado).toBe(EstadoDescarga.EN_PROGRESO);
  });

  it('actualizarProgreso() debe modificar el porcentaje de avance', () => {
    const descarga = crearDescarga();
    descarga.actualizarProgreso(42);
    expect(descarga.progreso).toBe(42);
  });

  it('completar() debe marcar estado COMPLETADA, progreso 100 y guardar los datos', () => {
    const descarga = crearDescarga();
    const buffer = Buffer.from('contenido de prueba');

    descarga.completar(buffer);

    expect(descarga.estado).toBe(EstadoDescarga.COMPLETADA);
    expect(descarga.progreso).toBe(100);
    expect(descarga.data).toEqual(buffer);
    expect(descarga.tiempoFin).toBeDefined();
  });

  it('fallar() debe marcar estado FALLIDA y registrar el mensaje de error', () => {
    const descarga = crearDescarga();

    descarga.fallar('Timeout al descargar');

    expect(descarga.estado).toBe(EstadoDescarga.FALLIDA);
    expect(descarga.error).toBe('Timeout al descargar');
    expect(descarga.tiempoFin).toBeDefined();
  });

  it('generarReporte() debe incluir id, estado, intentos y tiempoTotal', () => {
    const descarga = crearDescarga();
    descarga.intentos = 2;

    const reporte = descarga.generarReporte();

    expect(reporte.id).toBe('id-1');
    expect(reporte.estado).toBe(EstadoDescarga.PENDIENTE);
    expect(reporte.intentos).toBe(2);
    expect(typeof reporte.tiempoTotal).toBe('number');
    expect(reporte.tiempoTotal).toBeGreaterThanOrEqual(0);
  });

  it('generarId() debe producir identificadores únicos en formato UUID', () => {
    const id1 = Descarga.generarId();
    const id2 = Descarga.generarId();

    expect(id1).not.toBe(id2);
    expect(id1).toMatch(/^[0-9a-f-]{36}$/i);
  });
});
