import { UrlDescarga } from '../../../domain/value-objects/urlDescarga';
import { ErrorUrlInvalida } from '../../../domain/errors/index';

/**
 * Tests unitarios del value object UrlDescarga
 * (src/domain/value-objects/urlDescarga.ts).
 *
 * Nota: este value object define la regla de negocio "una URL debe
 * tener formato válido", pero actualmente no está integrado al flujo
 * de creación de descargas (ver downloadAPI.test.ts, sección
 * "documenta el comportamiento real..."). Se prueba aquí de forma
 * aislada porque la lógica en sí es correcta y reutilizable si en
 * el futuro se conecta al caso de uso.
 */
describe('UrlDescarga (value object)', () => {
  it('debe aceptar una URL HTTP bien formada', () => {
    const vo = new UrlDescarga('https://example.com/archivo.pdf');
    expect(vo.valor).toBe('https://example.com/archivo.pdf');
  });

  it('debe aceptar una URL FTP bien formada', () => {
    const vo = new UrlDescarga('ftp://ftp.example.com/datos.txt');
    expect(vo.valor).toBe('ftp://ftp.example.com/datos.txt');
  });

  it('debe lanzar ErrorUrlInvalida ante una cadena sin protocolo', () => {
    expect(() => new UrlDescarga('no-es-una-url')).toThrow(ErrorUrlInvalida);
  });

  it('debe lanzar ErrorUrlInvalida ante una cadena vacía', () => {
    expect(() => new UrlDescarga('')).toThrow(ErrorUrlInvalida);
  });

  it('el mensaje de error debe incluir la URL inválida recibida', () => {
    try {
      new UrlDescarga('algo-mal-formado');
      fail('Se esperaba que UrlDescarga lanzara una excepción.');
    } catch (error) {
      expect(error).toBeInstanceOf(ErrorUrlInvalida);
      expect((error as Error).message).toContain('algo-mal-formado');
    }
  });
});
