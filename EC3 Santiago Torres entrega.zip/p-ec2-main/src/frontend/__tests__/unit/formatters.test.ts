import {
  etiquetaEstado,
  severidadEstado,
  etiquetaTipo,
  truncarUrl,
  clampProgreso,
} from '../../utils/formatters';

/**
 * Tests unitarios de las utilidades de formateo del frontend
 * (src/frontend/utils/formatters.ts).
 */
describe('etiquetaEstado', () => {
  it('debe traducir cada estado del backend a una etiqueta legible', () => {
    expect(etiquetaEstado('PENDIENTE')).toBe('Pendiente');
    expect(etiquetaEstado('EN_PROGRESO')).toBe('En progreso');
    expect(etiquetaEstado('COMPLETADA')).toBe('Completada');
    expect(etiquetaEstado('FALLIDA')).toBe('Fallida');
  });

  it('debe devolver el valor original si el estado es desconocido', () => {
    expect(etiquetaEstado('ESTADO_RARO')).toBe('ESTADO_RARO');
  });
});

describe('severidadEstado', () => {
  it('debe mapear COMPLETADA a severidad success', () => {
    expect(severidadEstado('COMPLETADA')).toBe('success');
  });

  it('debe mapear FALLIDA a severidad danger', () => {
    expect(severidadEstado('FALLIDA')).toBe('danger');
  });

  it('debe devolver "secondary" para un estado desconocido', () => {
    expect(severidadEstado('ALGO')).toBe('secondary');
  });
});

describe('etiquetaTipo', () => {
  it('debe formatear los tipos conocidos en mayúsculas/legibles', () => {
    expect(etiquetaTipo('http')).toBe('HTTP');
    expect(etiquetaTipo('ftp')).toBe('FTP');
    expect(etiquetaTipo('mock')).toBe('Mock');
  });

  it('debe poner en mayúsculas un tipo desconocido', () => {
    expect(etiquetaTipo('raro')).toBe('RARO');
  });
});

describe('truncarUrl', () => {
  it('no debe truncar URLs cortas', () => {
    expect(truncarUrl('https://a.com')).toBe('https://a.com');
  });

  it('debe truncar URLs largas y agregar elipsis', () => {
    const urlLarga = `https://example.com/${'a'.repeat(80)}`;
    const resultado = truncarUrl(urlLarga, 20);
    expect(resultado.length).toBe(20);
    expect(resultado.endsWith('…')).toBe(true);
  });
});

describe('clampProgreso', () => {
  it('debe mantener valores dentro del rango 0-100', () => {
    expect(clampProgreso(50)).toBe(50);
  });

  it('debe limitar valores mayores a 100', () => {
    expect(clampProgreso(150)).toBe(100);
  });

  it('debe limitar valores negativos a 0', () => {
    expect(clampProgreso(-10)).toBe(0);
  });

  it('debe devolver 0 para NaN', () => {
    expect(clampProgreso(NaN)).toBe(0);
  });

  it('debe redondear valores decimales', () => {
    expect(clampProgreso(45.7)).toBe(46);
  });
});
