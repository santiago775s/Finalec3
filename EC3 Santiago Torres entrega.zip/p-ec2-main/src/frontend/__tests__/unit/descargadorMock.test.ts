import { DescargadorMock } from '../../../infrastructure/descargadores/descargadorMock';

/**
 * Tests unitarios de DescargadorMock
 * (src/infrastructure/descargadores/descargadorMock.ts), que también
 * ejercitan el comportamiento heredado de DescargadorBase
 * (ejecutarConReintento, getProgreso, cancelar).
 */
describe('DescargadorMock', () => {
  it('debe resolver exitosamente devolviendo un Buffer con la URL solicitada', async () => {
    const descargador = new DescargadorMock();
    const url = 'https://example.com/archivo.pdf';

    const resultado = await descargador.descargar(url);

    expect(resultado).toBeInstanceOf(Buffer);
    expect(resultado.toString()).toContain(url);
    expect(resultado.toString()).toContain('¡Mock exitoso!');
  });

  it('debe progresar hasta 100% al completar la descarga', async () => {
    const descargador = new DescargadorMock();
    await descargador.descargar('https://example.com/archivo.pdf');

    expect(descargador.getProgreso()).toBe(100);
  });

  it('cancelar() debe marcar la descarga como cancelada', () => {
    const descargador = new DescargadorMock();
    descargador.cancelar();

    // El estado de cancelación es privado/protegido; se valida
    // indirectamente a través de ejecutarConReintento, que revisa
    // `this.cancelado` antes de cada intento.
    return expect(
      descargador.ejecutarConReintento(() => descargador.descargar('https://example.com'), 1),
    ).rejects.toThrow();
  });
});
