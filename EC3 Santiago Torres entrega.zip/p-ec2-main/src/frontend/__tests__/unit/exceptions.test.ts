import { NotFoundException } from '../../../application/exceptions/notFoundException';
import { InvalidStateException } from '../../../application/exceptions/invalidStateException';
import { SystemSaturatedException } from '../../../application/exceptions/systemSaturatedException';
import { MaxRetriesExceededException } from '../../../application/exceptions/maxRetriesExceededException';

/**
 * Tests unitarios de las excepciones de la capa de aplicación
 * (src/application/exceptions/*.ts).
 */
describe('Excepciones de aplicación', () => {
  it('NotFoundException debe ser un Error con name correcto', () => {
    const error = new NotFoundException('No se encontró el recurso');
    expect(error).toBeInstanceOf(Error);
    expect(error.name).toBe('NotFoundException');
    expect(error.message).toBe('No se encontró el recurso');
  });

  it('InvalidStateException debe ser un Error con name correcto', () => {
    const error = new InvalidStateException('Transición de estado no permitida');
    expect(error).toBeInstanceOf(Error);
    expect(error.name).toBe('InvalidStateException');
  });

  it('SystemSaturatedException debe ser un Error con name correcto', () => {
    const error = new SystemSaturatedException('Buffer saturado');
    expect(error).toBeInstanceOf(Error);
    expect(error.name).toBe('SystemSaturatedException');
  });

  it('MaxRetriesExceededException debe ser un Error con name correcto', () => {
    const error = new MaxRetriesExceededException('Se superó el máximo de reintentos');
    expect(error).toBeInstanceOf(Error);
    expect(error.name).toBe('MaxRetriesExceededException');
  });
});
