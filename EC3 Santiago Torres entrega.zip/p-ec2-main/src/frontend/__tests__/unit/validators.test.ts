import { validarUrl, validarTipo, validarMaxReintentos } from '../../utils/validators';

/**
 * Tests unitarios de las utilidades de validación del frontend
 * (src/frontend/utils/validators.ts), usadas por DownloadForm.vue
 * a través de useDownloadForm.ts.
 */
describe('validarUrl', () => {
  it('debe aceptar una URL HTTPS válida', () => {
    expect(validarUrl('https://example.com/archivo.pdf').valido).toBe(true);
  });

  it('debe rechazar una cadena vacía', () => {
    const resultado = validarUrl('');
    expect(resultado.valido).toBe(false);
    expect(resultado.mensaje).toMatch(/obligatoria/i);
  });

  it('debe rechazar una cadena solo de espacios', () => {
    expect(validarUrl('   ').valido).toBe(false);
  });

  it('debe rechazar una URL sin protocolo', () => {
    const resultado = validarUrl('ejemplo.com/archivo');
    expect(resultado.valido).toBe(false);
    expect(resultado.mensaje).toMatch(/válida/i);
  });
});

describe('validarTipo', () => {
  it.each(['http', 'ftp', 'mock'])('debe aceptar el tipo "%s"', (tipo) => {
    expect(validarTipo(tipo).valido).toBe(true);
  });

  it('debe rechazar un tipo no soportado', () => {
    expect(validarTipo('torrent').valido).toBe(false);
  });

  it('debe rechazar un tipo vacío', () => {
    expect(validarTipo('').valido).toBe(false);
  });
});

describe('validarMaxReintentos', () => {
  it.each([1, 2, 3, 4, 5])('debe aceptar %i reintentos', (valor) => {
    expect(validarMaxReintentos(valor).valido).toBe(true);
  });

  it('debe rechazar 0 reintentos', () => {
    expect(validarMaxReintentos(0).valido).toBe(false);
  });

  it('debe rechazar más de 5 reintentos', () => {
    const resultado = validarMaxReintentos(6);
    expect(resultado.valido).toBe(false);
    expect(resultado.mensaje).toMatch(/entre 1 y 5/);
  });

  it('debe rechazar valores no enteros', () => {
    expect(validarMaxReintentos(2.5).valido).toBe(false);
  });
});
