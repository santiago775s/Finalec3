import request from 'supertest';
import {
  app,
  cerrarRecursosDePrueba,
  esperarCalentamientoWorkers,
  encontrarDescargaFtpFallida,
} from '../helpers/testApp';

/**
 * Pruebas de integración del backend (API REST de descargas).
 *
 * Objetivo (enunciado, sección 2): validar que el backend responde
 * correctamente cuando es consumido desde el frontend. Se usa el
 * tipo "mock" en la mayoría de los casos porque resuelve en ~600ms
 * sin depender de red externa, lo que mantiene las pruebas rápidas
 * y deterministas.
 *
 * Nota de cobertura: el enunciado pide también un caso "debe validar
 * reintentos máximos / esperar MaxRetriesExceededException". Revisando
 * el código fuente (reintentarDescargaUseCase.ts), esa excepción está
 * definida pero nunca se lanza: el caso de uso solo verifica que el
 * estado actual sea FALLIDA, sin límite de reintentos. No se simula
 * un comportamiento que el backend no implementa; en su lugar se
 * documenta la brecha en el informe técnico (sección "Desafíos y
 * Soluciones").
 */
describe('API Descargas - Integración Backend', () => {
  beforeAll(async () => {
    await esperarCalentamientoWorkers();
  });

  afterAll(() => {
    cerrarRecursosDePrueba();
  });

  describe('POST /api/descargas', () => {
    it('debe crear una nueva descarga correctamente', async () => {
      const respuesta = await request(app).post('/api/descargas').send({
        url: 'https://example.com/archivo.pdf',
        tipo: 'mock',
        maxReintentos: 3,
      });

      expect(respuesta.status).toBe(201);
      expect(respuesta.body).toMatchObject({
        url: 'https://example.com/archivo.pdf',
        tipo: 'mock',
        mensaje: 'Descarga encolada',
      });
      expect(typeof respuesta.body.id).toBe('string');
      expect(respuesta.body.id.length).toBeGreaterThan(0);
      expect(['PENDIENTE', 'EN_PROGRESO']).toContain(respuesta.body.estado);
    });

    it('documenta el comportamiento real ante una URL con formato inválido', async () => {
      // Aunque el dominio define un value object UrlDescarga que
      // valida el formato con `new URL(...)`, iniciarDercargaUseCase.ts
      // NO lo instancia: crea la entidad Descarga directamente con el
      // string crudo. En la práctica, el backend acepta hoy cualquier
      // string no vacío como URL y la rechaza recién al intentar
      // descargarla (asíncronamente, dentro del Worker Thread), sin
      // que eso se refleje como un error 4xx en la respuesta de creación.
      // Este test documenta el comportamiento actual; ver el informe
      // técnico (sección "Desafíos y Soluciones") para la brecha
      // identificada frente a lo que pide el enunciado.
      const respuesta = await request(app).post('/api/descargas').send({
        url: 'no-es-una-url',
        tipo: 'mock',
      });

      expect(respuesta.status).toBe(201);
      expect(respuesta.body.url).toBe('no-es-una-url');
    });

    it('debe manejar errores: tipo de descarga ausente o inválido', async () => {
      const respuesta = await request(app).post('/api/descargas').send({
        url: 'https://example.com/archivo.pdf',
        tipo: 'torrent',
      });

      expect(respuesta.status).toBe(400);
      expect(respuesta.body).toHaveProperty('error');
    });

    it('debe manejar errores: falta el campo url', async () => {
      const respuesta = await request(app).post('/api/descargas').send({
        tipo: 'mock',
      });

      expect(respuesta.status).toBe(400);
      expect(respuesta.body).toHaveProperty('error');
    });
  });

  describe('GET /api/descargas/:id/estado', () => {
    it('debe obtener el estado de una descarga existente', async () => {
      const creada = await request(app).post('/api/descargas').send({
        url: 'https://example.com/estado.pdf',
        tipo: 'mock',
      });
      const { id } = creada.body;

      const respuesta = await request(app).get(`/api/descargas/${id}/estado`);

      expect(respuesta.status).toBe(200);
      expect(respuesta.body).toMatchObject({
        id,
        url: 'https://example.com/estado.pdf',
        tipo: 'mock',
      });
      expect(respuesta.body).toHaveProperty('estado');
      expect(respuesta.body).toHaveProperty('progreso');
      expect(respuesta.body).toHaveProperty('intentos');
    });

    it('debe manejar errores: descarga inexistente', async () => {
      const respuesta = await request(app).get('/api/descargas/id-inexistente/estado');

      expect(respuesta.status).toBe(404);
      expect(respuesta.body).toHaveProperty('message');
    });
  });

  describe('GET /api/descargas', () => {
    it('debe listar todas las descargas con su resumen de totales', async () => {
      await request(app).post('/api/descargas').send({
        url: 'https://example.com/listado.pdf',
        tipo: 'mock',
      });

      const respuesta = await request(app).get('/api/descargas');

      expect(respuesta.status).toBe(200);
      expect(Array.isArray(respuesta.body.descargas)).toBe(true);
      expect(respuesta.body.descargas.length).toBeGreaterThan(0);
      expect(respuesta.body).toHaveProperty('total');
      expect(respuesta.body).toHaveProperty('completadas');
      expect(respuesta.body).toHaveProperty('pendientes');
      expect(respuesta.body).toHaveProperty('fallidas');
      expect(respuesta.body.total).toBe(respuesta.body.descargas.length);
    });
  });

  describe('POST /api/descargas/:id/reintentar', () => {
    it(
      'debe reintentar una descarga fallida (FTP, que falla ~25% de las veces)',
      async () => {
        // El DescargadorFtp falla aleatoriamente ~25% de las veces.
        // En vez de crear descargas una por una (lento, ya que cada
        // FTP simulado toma ~1.2s), se crean lotes de 10 EN PARALELO
        // y se toma la primera que termine en estado FALLIDA. Con
        // p≈0.25 por intento, la probabilidad de que un lote de 10 no
        // produzca ninguna falla es ≈0.75^10 ≈ 5.6%. Se permiten hasta
        // 3 lotes (≈0.056^3 ≈ 0.018% de que los tres fallen) para que
        // el test sea, en la práctica, completamente estable sin
        // mockear el dominio ni depender de un único intento de azar.
        const idFallida = await encontrarDescargaFtpFallida(
          async () => {
            const creada = await request(app).post('/api/descargas').send({
              url: 'https://example.com/ftp-test.txt',
              tipo: 'ftp',
            });
            return { id: creada.body.id };
          },
          async (id) => (await request(app).get(`/api/descargas/${id}/estado`)).body,
        );

        if (!idFallida) {
          console.warn(
            'No se logró generar ninguna descarga FTP fallida en 3 lotes de 10; se omite la aserción de reintento.',
          );
          return;
        }

        const respuesta = await request(app).post(`/api/descargas/${idFallida}/reintentar`);

        expect(respuesta.status).toBe(200);
        expect(respuesta.body).toMatchObject({
          id: idFallida,
          mensaje: 'Descarga reencolada',
        });
      },
      30000,
    );

    it('debe manejar errores: descarga inexistente al reintentar', async () => {
      const respuesta = await request(app).post('/api/descargas/id-inexistente/reintentar');

      expect(respuesta.status).toBe(404);
      expect(respuesta.body).toHaveProperty('message');
    });

    it('debe rechazar el reintento de una descarga que no está fallida', async () => {
      const creada = await request(app).post('/api/descargas').send({
        url: 'https://example.com/no-fallida.pdf',
        tipo: 'mock',
      });
      const { id } = creada.body;

      // Justo después de crearla, la descarga está PENDIENTE o
      // EN_PROGRESO, nunca FALLIDA.
      const respuesta = await request(app).post(`/api/descargas/${id}/reintentar`);

      expect(respuesta.status).toBe(400);
      expect(respuesta.body).toHaveProperty('message');
    });
  });
});
