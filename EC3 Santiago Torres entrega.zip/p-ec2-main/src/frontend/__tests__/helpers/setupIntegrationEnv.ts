// Se ejecuta antes de cargar cualquier módulo de la suite de
// integración. Asigna un puerto exclusivo para evitar que choque
// con el de la suite E2E cuando Jest las corre en procesos worker
// distintos en paralelo (ambas importan src/server.ts, que llama a
// app.listen(...) como efecto colateral).
process.env.PORT = '3101';
process.env.NODE_ENV = 'test';
