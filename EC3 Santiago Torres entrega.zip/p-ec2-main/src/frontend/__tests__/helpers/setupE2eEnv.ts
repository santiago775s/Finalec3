// Análogo a setupIntegrationEnv.ts, pero con un puerto distinto
// para la suite E2E, que también importa src/server.ts de forma
// independiente.
process.env.PORT = '3102';
process.env.NODE_ENV = 'test';
