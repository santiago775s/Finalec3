/**
 * Helper compartido por los tests de integración y E2E.
 *
 * Importa la app de Express ya configurada en src/server.ts. La
 * importación dispara, como efecto colateral, la inicialización
 * del WorkerPool real (src/shared/utils/workerPool.ts) con Worker
 * Threads de Node.js — el mismo comportamiento que ocurre al correr
 * `npm run dev`. Por eso estos tests usan principalmente el tipo
 * "mock" (DescargadorMock), que resuelve en ~600ms y no depende de
 * red externa, manteniendo las pruebas rápidas y deterministas.
 *
 * server.ts también llama a app.listen(...) al importarse, por lo
 * que el servidor queda escuchando en el puerto configurado
 * (por defecto 3000). Esto es intencional: nos permite reutilizar
 * exactamente el mismo arranque que usa la aplicación real, sin
 * mantener un "modo test" paralelo que pueda desincronizarse del
 * comportamiento de producción.
 */
import type { Express } from 'express';

// eslint-disable-next-line @typescript-eslint/no-var-requires
const app: Express = require('../../../server').default;
// El singleton real que usan los casos de uso es el exportado por
// workerPool.ts (no el de shared/instances.ts, que no está
// conectado al resto del código — ver iniciarDercargaUseCase.ts y
// reintentarDescargaUseCase.ts, ambos importan { workerPool } desde
// '../../shared/utils/workerPool').
// eslint-disable-next-line @typescript-eslint/no-var-requires
const { workerPool } = require('../../../shared/utils/workerPool');

export { app };

/**
 * Tiempo de "calentamiento" tras importar la app. Los 3 Worker
 * Threads reales del WorkerPool (workerPool.ts) cargan
 * `ts-node/register` la primera vez que arrancan; medido en este
 * entorno, ese arranque puede tomar ~7 segundos antes de que cada
 * worker emita "Worker ready and waiting for messages". Sin esta
 * espera, la primera petición de la suite queda encolada detrás del
 * arranque de los workers y los timeouts de polling fallan de forma
 * intermitente (la descarga queda en PENDIENTE/EN_PROGRESO mucho más
 * tiempo del esperado).
 */
export async function esperarCalentamientoWorkers(): Promise<void> {
  await esperar(9000);
}

/**
 * Cierra de forma ordenada los Worker Threads reales abiertos por
 * el WorkerPool. Sin esto, Jest queda colgado al final de la
 * ejecución porque los workers (y el socket de app.listen) siguen
 * vivos en segundo plano.
 *
 * Se debe invocar desde un afterAll() en cada archivo de test que
 * importe testApp.
 */
export function cerrarRecursosDePrueba(): void {
  try {
    workerPool.destruir();
  } catch {
    // No crítico para el resultado de los tests si ya fue destruido.
  }
}

/** Pequeña espera utilitaria para los tests asíncronos (polling). */
export function esperar(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

/**
 * Hace polling sobre una función hasta que la condición se cumpla
 * o se agote el número máximo de intentos. Se usa para esperar a
 * que una descarga Mock cambie de estado (EN_PROGRESO -> COMPLETADA
 * o FALLIDA) sin depender de tiempos fijos frágiles.
 */
export async function esperarHasta<T>(
  obtener: () => Promise<T>,
  condicion: (valor: T) => boolean,
  opciones: { intentos?: number; intervaloMs?: number } = {},
): Promise<T> {
  const { intentos = 20, intervaloMs = 200 } = opciones;
  let ultimoValor: T;

  for (let i = 0; i < intentos; i++) {
    ultimoValor = await obtener();
    if (condicion(ultimoValor)) {
      return ultimoValor;
    }
    await esperar(intervaloMs);
  }

  return ultimoValor!;
}

/**
 * Crea descargas FTP en lotes paralelos hasta encontrar una que
 * termine en estado FALLIDA (DescargadorFtp falla aleatoriamente
 * ~25% de las veces, ver descargadorFtp.ts). Se usa supertest
 * (pasado como `agenteRequest`) en vez de importar `request` aquí
 * para no atar este helper a una librería de HTTP específica.
 *
 * Con p≈0.25 por intento, un lote de `tamanoLote` descargas tiene
 * probabilidad (1-p)^tamanoLote de no producir ninguna falla; repetir
 * por `maxLotes` lotes hace que esa probabilidad caiga a niveles
 * insignificantes sin necesidad de mockear el dominio.
 */
export async function encontrarDescargaFtpFallida(
  crearYConsultar: () => Promise<{ id: string }>,
  consultarEstado: (id: string) => Promise<{ id: string; estado: string }>,
  opciones: { tamanoLote?: number; maxLotes?: number } = {},
): Promise<string | null> {
  const { tamanoLote = 10, maxLotes = 3 } = opciones;

  for (let lote = 0; lote < maxLotes; lote++) {
    const creadas = await Promise.all(
      Array.from({ length: tamanoLote }, () => crearYConsultar()),
    );

    const estadosFinales = await Promise.all(
      creadas.map((creada) =>
        esperarHasta(
          () => consultarEstado(creada.id),
          (estado) => estado.estado === 'FALLIDA' || estado.estado === 'COMPLETADA',
          { intentos: 15, intervaloMs: 150 },
        ),
      ),
    );

    const fallida = estadosFinales.find((e) => e.estado === 'FALLIDA');
    if (fallida) {
      return fallida.id;
    }
  }

  return null;
}
