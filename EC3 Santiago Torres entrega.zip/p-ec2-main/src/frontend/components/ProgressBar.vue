<script setup lang="ts">
import { computed } from 'vue';
import { clampProgreso } from '../utils/formatters';

/**
 * Indicador de progreso de una descarga individual.
 */
const props = defineProps<{
  progress: number;
  /** Color de acento opcional (token hex). Por defecto usa el azul de marca. */
  accent?: string;
}>();

const porcentaje = computed(() => clampProgreso(props.progress));
const colorAccent = computed(() => props.accent ?? '#3B82F6');
</script>

<template>
  <div class="progress-bar" role="progressbar" :aria-valuenow="porcentaje" aria-valuemin="0" aria-valuemax="100">
    <div
      class="progress-bar__fill"
      :style="{ width: `${porcentaje}%`, backgroundColor: colorAccent }"
    />
    <span class="progress-bar__label">{{ porcentaje }}%</span>
  </div>
</template>

<style scoped>
.progress-bar {
  position: relative;
  width: 100%;
  height: 1.25rem;
  border-radius: 999px;
  background-color: #e5e7eb;
  overflow: hidden;
}

.progress-bar__fill {
  height: 100%;
  border-radius: 999px;
  transition: width 0.35s ease;
}

.progress-bar__label {
  position: absolute;
  inset: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 0.7rem;
  font-weight: 600;
  color: #1f2937;
  mix-blend-mode: difference;
  filter: invert(1) grayscale(1) contrast(2);
}
</style>
