<script setup lang="ts">
import { computed } from 'vue';
import Dialog from 'primevue/dialog';
import DownloadStatus from './DownloadStatus.vue';
import ProgressBar from './ProgressBar.vue';
import type { Descarga } from '../types';
import { etiquetaTipo, formatearFecha } from '../utils/formatters';

/**
 * Detalle de una descarga individual, mostrado en un modal.
 *
 * Nota de alcance: el backend no expone un endpoint de detalle
 * (GET /api/descargas/:id), por lo que esta vista reutiliza los
 * mismos datos ya presentes en la fila de la tabla / store, en
 * lugar de hacer una llamada adicional a la red.
 */
const props = defineProps<{
  visible: boolean;
  download: Descarga | null;
}>();

const emit = defineEmits<{
  (e: 'update:visible', value: boolean): void;
}>();

const visibleInterno = computed({
  get: () => props.visible,
  set: (valor: boolean) => emit('update:visible', valor),
});
</script>

<template>
  <Dialog
    v-model:visible="visibleInterno"
    modal
    header="Detalle de la descarga"
    class="download-card-dialog"
    :style="{ width: '28rem' }"
  >
    <div v-if="download" class="download-card">
      <div class="download-card__row">
        <span class="download-card__label">ID</span>
        <code class="download-card__value">{{ download.id }}</code>
      </div>

      <div class="download-card__row">
        <span class="download-card__label">URL</span>
        <span class="download-card__value download-card__url">{{ download.url }}</span>
      </div>

      <div class="download-card__row">
        <span class="download-card__label">Tipo</span>
        <span class="download-card__value">{{ etiquetaTipo(download.tipo) }}</span>
      </div>

      <div class="download-card__row">
        <span class="download-card__label">Estado</span>
        <DownloadStatus :status="download.estado" />
      </div>

      <div class="download-card__row">
        <span class="download-card__label">Progreso</span>
        <ProgressBar :progress="download.progreso" />
      </div>

      <div class="download-card__row">
        <span class="download-card__label">Intentos</span>
        <span class="download-card__value">{{ download.intentos }}</span>
      </div>

      <div class="download-card__row">
        <span class="download-card__label">Registrada</span>
        <span class="download-card__value">{{ formatearFecha(download.fechaRegistro) }}</span>
      </div>
    </div>
  </Dialog>
</template>

<style scoped>
.download-card {
  display: flex;
  flex-direction: column;
  gap: 0.85rem;
}

.download-card__row {
  display: flex;
  flex-direction: column;
  gap: 0.2rem;
}

.download-card__label {
  font-size: 0.72rem;
  text-transform: uppercase;
  letter-spacing: 0.05em;
  font-weight: 700;
  color: #6b7280;
}

.download-card__value {
  font-size: 0.92rem;
  color: #111827;
}

.download-card__url {
  word-break: break-all;
}
</style>
