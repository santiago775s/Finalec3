<script setup lang="ts">
import { computed } from 'vue';
import Chart from 'primevue/chart';
import type { Descarga } from '../types';

/**
 * Gráfico de dona: distribución de descargas por estado.
 * (Sección 1.1 del enunciado, "Gráficos (opcional pero recomendado)").
 */
const props = defineProps<{
  downloads: Descarga[];
}>();

const conteoPorEstado = computed(() => {
  const conteo: Record<string, number> = {
    PENDIENTE: 0,
    EN_PROGRESO: 0,
    COMPLETADA: 0,
    FALLIDA: 0,
    REINTENTANDO: 0,
    CANCELADA: 0,
  };
  for (const d of props.downloads) {
    conteo[d.estado] = (conteo[d.estado] ?? 0) + 1;
  }
  return conteo;
});

const chartData = computed(() => ({
  labels: ['Pendiente', 'En progreso', 'Completada', 'Fallida', 'Reintentando', 'Cancelada'],
  datasets: [
    {
      data: [
        conteoPorEstado.value.PENDIENTE,
        conteoPorEstado.value.EN_PROGRESO,
        conteoPorEstado.value.COMPLETADA,
        conteoPorEstado.value.FALLIDA,
        conteoPorEstado.value.REINTENTANDO,
        conteoPorEstado.value.CANCELADA,
      ],
      backgroundColor: ['#9ca3af', '#3b82f6', '#22c55e', '#ef4444', '#f59e0b', '#6b7280'],
      borderWidth: 0,
    },
  ],
}));

const chartOptions = {
  plugins: {
    legend: {
      position: 'bottom' as const,
      labels: { boxWidth: 12, font: { size: 11 } },
    },
  },
  cutout: '62%',
};
</script>

<template>
  <div class="status-chart">
    <h3 class="status-chart__title">Distribución de estados</h3>
    <Chart type="doughnut" :data="chartData" :options="chartOptions" class="status-chart__canvas" />
  </div>
</template>

<style scoped>
.status-chart {
  background-color: #ffffff;
  border-radius: 1rem;
  padding: 1.25rem;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.08);
  display: flex;
  flex-direction: column;
  gap: 0.75rem;
}

.status-chart__title {
  margin: 0;
  font-size: 0.95rem;
  font-weight: 700;
  color: #111827;
}

.status-chart__canvas {
  max-height: 220px;
}
</style>
