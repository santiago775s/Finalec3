<script setup lang="ts">
import { computed } from 'vue';
import Chart from 'primevue/chart';
import type { Descarga } from '../types';

/**
 * Gráfico de línea: descargas completadas agrupadas por hora del día,
 * según la hora local en que el frontend detectó cada registro
 * (el backend no expone fechaCreacion/fechaFin en sus respuestas
 * actuales, ver downloadStore.ts -> fechaRegistro).
 */
const props = defineProps<{
  downloads: Descarga[];
}>();

const completadasPorHora = computed(() => {
  const horas = Array.from({ length: 24 }, () => 0);
  for (const d of props.downloads) {
    if (d.estado !== 'COMPLETADA') continue;
    const fecha = new Date(d.fechaRegistro);
    if (Number.isNaN(fecha.getTime())) continue;
    horas[fecha.getHours()] += 1;
  }
  return horas;
});

const chartData = computed(() => ({
  labels: Array.from({ length: 24 }, (_, h) => `${h.toString().padStart(2, '0')}:00`),
  datasets: [
    {
      label: 'Completadas',
      data: completadasPorHora.value,
      borderColor: '#22c55e',
      backgroundColor: 'rgba(34, 197, 94, 0.15)',
      tension: 0.35,
      fill: true,
      pointRadius: 2,
    },
  ],
}));

const chartOptions = {
  plugins: {
    legend: { display: false },
  },
  scales: {
    y: {
      beginAtZero: true,
      ticks: { precision: 0 },
    },
    x: {
      ticks: { maxTicksLimit: 8, font: { size: 10 } },
    },
  },
};
</script>

<template>
  <div class="hourly-chart">
    <h3 class="hourly-chart__title">Descargas completadas por hora</h3>
    <Chart type="line" :data="chartData" :options="chartOptions" class="hourly-chart__canvas" />
  </div>
</template>

<style scoped>
.hourly-chart {
  background-color: #ffffff;
  border-radius: 1rem;
  padding: 1.25rem;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.08);
  display: flex;
  flex-direction: column;
  gap: 0.75rem;
}

.hourly-chart__title {
  margin: 0;
  font-size: 0.95rem;
  font-weight: 700;
  color: #111827;
}

.hourly-chart__canvas {
  max-height: 220px;
}
</style>
