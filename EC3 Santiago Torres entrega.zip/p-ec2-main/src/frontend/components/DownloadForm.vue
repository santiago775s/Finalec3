<script setup lang="ts">
import InputText from 'primevue/inputtext';
import Dropdown from 'primevue/dropdown';
import InputNumber from 'primevue/inputnumber';
import Button from 'primevue/button';
import Message from 'primevue/message';
import { useDownloadForm } from '../composables/useDownloadForm';

/**
 * Formulario de creación de una nueva descarga.
 *
 * Props:
 *  - onSubmit: callback opcional invocado luego de crear la descarga
 *    exitosamente, tal como pide el enunciado (DownloadForm -> onSubmit).
 *    La creación real ocurre internamente a través del composable
 *    useDownloadForm + el store, por lo que onSubmit es informativo
 *    para el componente padre (ej. mostrar un toast extra).
 */
const props = defineProps<{
  onSubmit?: (data: { url: string; tipo: string; maxReintentos: number }) => void;
}>();

const {
  form,
  erroresCampo,
  tocado,
  enviando,
  mensajeExito,
  formularioValido,
  marcarTocado,
  enviarFormulario,
} = useDownloadForm();

const opcionesTipo = [
  { label: 'HTTP', value: 'http' },
  { label: 'FTP', value: 'ftp' },
  { label: 'Mock', value: 'mock' },
];

async function manejarSubmit(): Promise<void> {
  const datosAntes = { url: form.url, tipo: form.tipo, maxReintentos: form.maxReintentos };
  const exito = await enviarFormulario();
  if (exito && props.onSubmit) {
    props.onSubmit(datosAntes);
  }
}
</script>

<template>
  <form class="download-form" @submit.prevent="manejarSubmit" novalidate>
    <h2 class="download-form__title">Nueva descarga</h2>

    <div class="download-form__field">
      <label for="campo-url">URL del recurso</label>
      <InputText
        id="campo-url"
        v-model="form.url"
        placeholder="https://ejemplo.com/archivo.pdf"
        class="download-form__input"
        :class="{ 'p-invalid': tocado.url && erroresCampo.url }"
        @blur="marcarTocado('url')"
        @input="tocado.url && marcarTocado('url')"
        aria-describedby="error-url"
      />
      <small v-if="tocado.url && erroresCampo.url" id="error-url" class="download-form__error">
        {{ erroresCampo.url }}
      </small>
    </div>

    <div class="download-form__row">
      <div class="download-form__field">
        <label for="campo-tipo">Tipo de descarga</label>
        <Dropdown
          id="campo-tipo"
          v-model="form.tipo"
          :options="opcionesTipo"
          option-label="label"
          option-value="value"
          placeholder="Selecciona un tipo"
          class="download-form__input"
          :class="{ 'p-invalid': tocado.tipo && erroresCampo.tipo }"
          @change="marcarTocado('tipo')"
        />
        <small v-if="tocado.tipo && erroresCampo.tipo" class="download-form__error">
          {{ erroresCampo.tipo }}
        </small>
      </div>

      <div class="download-form__field">
        <label for="campo-reintentos">Reintentos máximos</label>
        <InputNumber
          id="campo-reintentos"
          v-model="form.maxReintentos"
          :min="1"
          :max="5"
          show-buttons
          class="download-form__input"
          :class="{ 'p-invalid': tocado.maxReintentos && erroresCampo.maxReintentos }"
          @blur="marcarTocado('maxReintentos')"
        />
        <small v-if="tocado.maxReintentos && erroresCampo.maxReintentos" class="download-form__error">
          {{ erroresCampo.maxReintentos }}
        </small>
      </div>
    </div>

    <Message v-if="mensajeExito" severity="success" :closable="false" class="download-form__success">
      {{ mensajeExito }}
    </Message>

    <Button
      type="submit"
      label="Iniciar Descarga"
      icon="pi pi-download"
      :loading="enviando"
      :disabled="!formularioValido && (tocado.url || tocado.tipo || tocado.maxReintentos)"
      class="download-form__submit"
    />
  </form>
</template>

<style scoped>
.download-form {
  display: flex;
  flex-direction: column;
  gap: 1rem;
  padding: 1.5rem;
  border-radius: 1rem;
  background-color: #ffffff;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.08);
}

.download-form__title {
  margin: 0;
  font-size: 1.1rem;
  font-weight: 700;
  color: #111827;
}

.download-form__row {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 1rem;
}

.download-form__field {
  display: flex;
  flex-direction: column;
  gap: 0.35rem;
}

.download-form__field label {
  font-size: 0.85rem;
  font-weight: 600;
  color: #374151;
}

.download-form__input {
  width: 100%;
}

.download-form__error {
  color: #dc2626;
  font-size: 0.78rem;
}

.download-form__submit {
  align-self: flex-start;
  margin-top: 0.25rem;
}

@media (max-width: 640px) {
  .download-form__row {
    grid-template-columns: 1fr;
  }
}
</style>
