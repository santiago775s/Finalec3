<script setup lang="ts">
import { computed } from 'vue';
import Tag from 'primevue/tag';
import type { EstadoDescarga } from '../types';
import { etiquetaEstado, severidadEstado } from '../utils/formatters';

/**
 * Badge de estado individual de una descarga.
 * Mapea EstadoDescarga (backend) a una etiqueta legible y a la
 * severidad de color correspondiente (PrimeVue Tag).
 */
const props = defineProps<{
  status: EstadoDescarga | string;
}>();

const etiqueta = computed(() => etiquetaEstado(props.status));
const severidad = computed(() => severidadEstado(props.status));
</script>

<template>
  <Tag :value="etiqueta" :severity="severidad" class="download-status" />
</template>

<style scoped>
.download-status {
  font-weight: 600;
  letter-spacing: 0.02em;
  text-transform: uppercase;
  font-size: 0.7rem;
}
</style>
