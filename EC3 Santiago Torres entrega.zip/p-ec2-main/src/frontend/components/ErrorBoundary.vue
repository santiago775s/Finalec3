<script setup lang="ts">
import { onErrorCaptured, ref } from 'vue';

/**
 * Captura errores no manejados lanzados por cualquier componente
 * descendiente en su árbol de renderizado, evitando que un fallo
 * puntual (ej. un dato inesperado de la API) rompa el dashboard
 * completo.
 */
const tieneError = ref(false);
const mensajeError = ref('');

onErrorCaptured((error) => {
  tieneError.value = true;
  mensajeError.value = error instanceof Error ? error.message : 'Error desconocido en la interfaz.';
  // Evita que el error siga propagándose hacia componentes padre.
  return false;
});

function reintentar(): void {
  tieneError.value = false;
  mensajeError.value = '';
}
</script>

<template>
  <div v-if="tieneError" class="error-boundary" role="alert">
    <i class="pi pi-exclamation-triangle error-boundary__icon" aria-hidden="true" />
    <p class="error-boundary__title">Algo salió mal al mostrar esta sección.</p>
    <p class="error-boundary__detail">{{ mensajeError }}</p>
    <button type="button" class="error-boundary__retry" @click="reintentar">
      Reintentar
    </button>
  </div>
  <slot v-else />
</template>

<style scoped>
.error-boundary {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 0.5rem;
  padding: 2rem;
  border: 1px dashed #ef4444;
  border-radius: 0.75rem;
  background-color: #fef2f2;
  color: #991b1b;
  text-align: center;
}

.error-boundary__icon {
  font-size: 1.5rem;
}

.error-boundary__title {
  font-weight: 700;
  margin: 0;
}

.error-boundary__detail {
  margin: 0;
  font-size: 0.85rem;
  opacity: 0.85;
}

.error-boundary__retry {
  margin-top: 0.5rem;
  padding: 0.4rem 1rem;
  border-radius: 0.5rem;
  border: none;
  background-color: #991b1b;
  color: white;
  cursor: pointer;
  font-weight: 600;
}

.error-boundary__retry:hover {
  background-color: #7f1d1d;
}
</style>
