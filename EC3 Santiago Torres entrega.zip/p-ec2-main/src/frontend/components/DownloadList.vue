<script setup lang="ts">
import { ref, computed } from 'vue';
import DataTable from 'primevue/datatable';
import Column from 'primevue/column';
import Button from 'primevue/button';
import InputText from 'primevue/inputtext';
import Tooltip from 'primevue/tooltip';
import DownloadStatus from './DownloadStatus.vue';
import ProgressBar from './ProgressBar.vue';
import DownloadCard from './DownloadCard.vue';
import type { Descarga } from '../types';
import { etiquetaTipo, truncarUrl, formatearFecha } from '../utils/formatters';

/**
 * Tabla de descargas con acciones de ver detalle y reintentar.
 *
 * Props:
 *  - downloads: Download[] — lista de descargas a mostrar, controlada
 *    por el componente padre (DashboardPage.vue) a través del store.
 */
const props = defineProps<{
  downloads: Descarga[];
}>();

const emit = defineEmits<{
  (e: 'reintentar', id: string): void;
}>();

const filtro = ref('');
const detalleVisible = ref(false);
const descargaSeleccionada = ref<Descarga | null>(null);

const descargasFiltradas = computed(() => {
  const termino = filtro.value.trim().toLowerCase();
  if (!termino) return props.downloads;
  return props.downloads.filter(
    (d) =>
      d.url.toLowerCase().includes(termino) ||
      d.id.toLowerCase().includes(termino) ||
      d.estado.toLowerCase().includes(termino),
  );
});

function abrirDetalle(descarga: Descarga): void {
  descargaSeleccionada.value = descarga;
  detalleVisible.value = true;
}

function puedeReintentar(descarga: Descarga): boolean {
  return descarga.estado === 'FALLIDA';
}

function solicitarReintento(id: string): void {
  emit('reintentar', id);
}
</script>

<template>
  <div class="download-list">
    <div class="download-list__toolbar">
      <h2 class="download-list__title">Descargas</h2>
      <span class="p-input-icon-left download-list__search">
        <i class="pi pi-search" />
        <InputText v-model="filtro" placeholder="Buscar por URL, ID o estado…" />
      </span>
    </div>

    <DataTable
      :value="descargasFiltradas"
      data-key="id"
      class="download-list__table"
      responsive-layout="scroll"
      :row-class="(data: Descarga) => `download-row download-row--${data.estado.toLowerCase()}`"
      striped-rows
      paginator
      :rows="8"
      :rows-per-page-options="[8, 16, 32]"
    >
      <template #empty>
        <div class="download-list__empty">
          No hay descargas todavía. Crea una desde el formulario para empezar a verla aquí.
        </div>
      </template>

      <Column field="id" header="ID">
        <template #body="{ data }">
          <code class="download-list__id">{{ data.id.slice(0, 8) }}…</code>
        </template>
      </Column>

      <Column field="url" header="URL">
        <template #body="{ data }">
          <span :title="data.url">{{ truncarUrl(data.url, 40) }}</span>
        </template>
      </Column>

      <Column field="tipo" header="Tipo">
        <template #body="{ data }">{{ etiquetaTipo(data.tipo) }}</template>
      </Column>

      <Column field="estado" header="Estado">
        <template #body="{ data }">
          <DownloadStatus :status="data.estado" />
        </template>
      </Column>

      <Column field="progreso" header="Progreso">
        <template #body="{ data }">
          <ProgressBar :progress="data.progreso" />
        </template>
      </Column>

      <Column field="intentos" header="Intentos" />

      <Column field="fechaRegistro" header="Fecha">
        <template #body="{ data }">{{ formatearFecha(data.fechaRegistro) }}</template>
      </Column>

      <Column header="Acciones">
        <template #body="{ data }">
          <div class="download-list__actions">
            <Button
              icon="pi pi-eye"
              text
              rounded
              aria-label="Ver detalles"
              v-tooltip.top="'Ver detalles'"
              @click="abrirDetalle(data)"
            />
            <Button
              icon="pi pi-refresh"
              text
              rounded
              severity="warning"
              aria-label="Reintentar"
              v-tooltip.top="'Reintentar'"
              :disabled="!puedeReintentar(data)"
              @click="solicitarReintento(data.id)"
            />
            <Button
              icon="pi pi-times"
              text
              rounded
              severity="danger"
              aria-label="Cancelar"
              v-tooltip.top="'Cancelar (no disponible: el backend aún no expone este endpoint)'"
              disabled
            />
          </div>
        </template>
      </Column>
    </DataTable>

    <DownloadCard v-model:visible="detalleVisible" :download="descargaSeleccionada" />
  </div>
</template>

<style scoped>
.download-list {
  display: flex;
  flex-direction: column;
  gap: 1rem;
  background-color: #ffffff;
  border-radius: 1rem;
  padding: 1.5rem;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.08);
}

.download-list__toolbar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  flex-wrap: wrap;
  gap: 0.75rem;
}

.download-list__title {
  margin: 0;
  font-size: 1.1rem;
  font-weight: 700;
  color: #111827;
}

.download-list__search input {
  width: 16rem;
}

.download-list__id {
  font-size: 0.78rem;
  color: #4b5563;
}

.download-list__actions {
  display: flex;
  gap: 0.25rem;
}

.download-list__empty {
  text-align: center;
  padding: 2rem 1rem;
  color: #6b7280;
}

:deep(.download-row--pendiente) {
  background-color: #f9fafb;
}
:deep(.download-row--en_progreso) {
  background-color: #eff6ff;
}
:deep(.download-row--completada) {
  background-color: #f0fdf4;
}
:deep(.download-row--fallida) {
  background-color: #fef2f2;
}
:deep(.download-row--reintentando) {
  background-color: #fffbeb;
}

@media (max-width: 640px) {
  .download-list__search input {
    width: 100%;
  }
}
</style>
